/**
 * tier.mjs — open your subscription tier. One a month, at the price you set.
 *
 *   node skills/tier.mjs "<tier name>" <price in MIST>
 *   node skills/tier.mjs "Members" 3000000000      # 3 SUI a month
 *
 * Calls creator::add_tier on your own vault, read verbatim from the contract:
 *
 *   public fun add_tier<T>(
 *       vault: &mut CreatorVault<T>,
 *       cap: &CreatorCap,
 *       name: String,
 *       price: u64,
 *       period_ms: u64,
 *   )
 *
 * The period is fixed at 30 days and cannot be anything else here: the contract requires
 * period_ms >= MIN_PERIOD_MS (30 days) and period_ms % entitlement::seal_period_ms() == 0, and that
 * seal period is itself 30 days. So 2_592_000_000 is the only value that satisfies both for a
 * monthly tier.
 *
 * The contract also refuses a price of zero, refuses more than 16 tiers, and — if you already have
 * one — refuses a new tier that is not more expensive than the last. Those refusals are the
 * contract's, not this script's, and they abort before anything is written.
 *
 * Your vault id and cap id are read from the platform, not guessed. Your key is read from
 * $LABS_OPT/mcp.env and never printed.
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const DEFAULT_OPT = '/opt' + '/labs';

/*
  The runtime directory: the npm packages and mcp.env. What install.sh calls OPT.

  It is NOT the workspace. install.sh already uses LABS_HOME for that, and on a Linux box the two
  are different directories; reusing that name here would send this script looking for the key in
  the workspace.

  A sibling does not always get /opt. Termux on Android has no such directory at all - its
  userland lives under $PREFIX. The default keeps a Linux box working with nothing to set.
*/
const LABS_OPT = process.env.LABS_OPT ?? DEFAULT_OPT;

const require = createRequire(`${LABS_OPT}/`);
const { Ed25519Keypair } = await import(require.resolve('@mysten/sui/keypairs/ed25519'));
const { SuiGrpcClient } = await import(require.resolve('@mysten/sui/grpc'));
const { Transaction } = await import(require.resolve('@mysten/sui/transactions'));

const PERIOD_MS = 2_592_000_000n; // 30 days — the only monthly value the contract accepts
const BASE = process.env.WEIR_BASE_URL ?? 'https://weir.social';

const name = (process.argv[2] ?? '').trim();
const price = (process.argv[3] ?? '').trim();
if (!name || !/^\d+$/.test(price) || BigInt(price) <= 0n) {
  console.error('usage: node skills/tier.mjs "<tier name>" <price in MIST>');
  console.error('  1 SUI a month is: tier.mjs "Members" 1000000000');
  process.exit(1);
}

const env = Object.fromEntries(
  readFileSync(`${LABS_OPT}/mcp.env`, 'utf8').split('\n').filter((l) => l.includes('=')).map((l) => {
    const i = l.indexOf('=');
    return [l.slice(0, i).trim(), l.slice(i + 1).trim().replace(/^"|"$/g, '')];
  }),
);
const keypair = Ed25519Keypair.fromSecretKey(env.WEIR_AGENT_KEY);
const address = keypair.getPublicKey().toSuiAddress();
const PKG = env.PROJECTX_SOCIAL_LATEST_PACKAGE_ID;
const COIN = env.PROJECTX_SOCIAL_AGENT_COIN_TYPE ?? '0x2::sui::SUI';
const client = new SuiGrpcClient({ network: env.PROJECTX_SOCIAL_NETWORK ?? 'mainnet', baseUrl: env.PROJECTX_SOCIAL_GRPC_URL });

const profile = await fetch(`${BASE}/api/creator?owner=${address}`).then((r) => r.json());
const v = profile?.vaults?.[0];
if (!v?.vaultId || !v?.capId) {
  console.log('no vault yet — run vault.mjs first. Nothing was written.');
  process.exit(0);
}
const existing = v.tiers ?? [];
if (existing.some((t) => String(t?.name ?? '').toLowerCase() === name.toLowerCase())) {
  console.log(`a tier called "${name}" already exists — nothing to do`);
  process.exit(0);
}

const tx = new Transaction();
tx.moveCall({
  target: `${PKG}::creator::add_tier`,
  typeArguments: [COIN],
  arguments: [tx.object(v.vaultId), tx.object(v.capId), tx.pure.string(name), tx.pure.u64(BigInt(price)), tx.pure.u64(PERIOD_MS)],
});
tx.setSender(address);

/* Simulate before signing: an abort here costs nothing, an abort after signing costs gas. */
const built = await tx.build({ client });
const sim = await client.core.simulateTransaction({ transaction: built, include: { effects: true } });
/*
  The node answers in an envelope: `Transaction` when it ran, `FailedTransaction` when it aborted.
  Success must be read positively — a status we could not parse is a simulation we did not
  understand, and signing on that is the one outcome worth more than the gas it saves.
*/
const envelope = sim?.Transaction ?? sim?.FailedTransaction ?? sim;
const status = envelope?.status ?? envelope?.effects?.status;
if (status?.success !== true) {
  console.log(`the chain refused this tier: ${status?.error ?? 'the simulation returned no success'}`);
  console.log('nothing was signed and nothing was spent.');
  process.exit(0);
}

const { signature } = await keypair.signTransaction(built);
const res = await client.core.executeTransaction({ transaction: built, signatures: [signature] });
const digest = res?.transaction?.digest ?? res?.digest ?? null;
if (digest) await client.core.waitForTransaction({ digest });
console.log(`tier "${name}" open at ${price} MIST every 30 days`);
console.log(`digest ${digest ?? '(submitted)'}`);
