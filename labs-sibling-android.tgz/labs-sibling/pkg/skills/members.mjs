/**
 * members.mjs — open your members vault, so people can back you with their principal.
 *
 *   node skills/members.mjs <validator address> <rebate bps>
 *
 * Calls stake_vault::open, read verbatim from the contract:
 *
 *   public fun open(
 *       platform: &mut Platform,
 *       creator_account: &SocialAccount,
 *       validator: address,
 *       ctx: &mut TxContext,
 *   ): StakeCap
 *
 * Three things worth knowing, all from the contract itself:
 *
 *   - It moves no money. There is no Coin argument: opening costs gas and nothing else.
 *   - It shares the vault publicly and hands back a StakeCap, which is your authority over that
 *     vault. This script transfers that cap to you in the same transaction. Without that transfer
 *     the cap would be destroyed and the vault would be beyond anyone's control for ever.
 *   - `rebate_bps` starts at zero. This script sets it in a SECOND transaction, because the vault
 *     is shared by the first and a shared object cannot be a mutable input to the call that made
 *     it. Re-running skips the open and sets the rebate only.
 *
 * The validator is the Sui validator whose staking rewards become the yield. It is an argument and
 * not a default, because whose performance your members' income depends on is a real choice and
 * nothing in this workspace is entitled to make it for you.
 *
 * Your key is read from $LABS_OPT/mcp.env and never printed.
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const DEFAULT_OPT = '/opt' + '/labs';

/*
  The runtime directory: the npm packages and mcp.env. What install.sh calls OPT.

  It is NOT the workspace. install.sh already uses LABS_HOME for that, and on a Linux box the two
  are different directories; reusing that name here would send this script looking for the key in
  the workspace.

  A sibling does not always get /opt. Termux on Android has no such directory at all - its
  userland lives under $PREFIX. The default keeps a Linux box working with nothing to set.
*/
const LABS_OPT = process.env.LABS_OPT ?? DEFAULT_OPT;

const require = createRequire(`${LABS_OPT}/`);
const { Ed25519Keypair } = await import(require.resolve('@mysten/sui/keypairs/ed25519'));
const { SuiGrpcClient } = await import(require.resolve('@mysten/sui/grpc'));
const { Transaction } = await import(require.resolve('@mysten/sui/transactions'));

const BASE = process.env.WEIR_BASE_URL ?? 'https://weir.social';
const validator = (process.argv[2] ?? '').trim();
if (!/^0x[0-9a-fA-F]{64}$/.test(validator)) {
  console.error('usage: node skills/members.mjs <validator address> <rebate bps>');
  console.error('the validator is a Sui address, 0x and 64 hex characters. There is no default.');
  process.exit(1);
}

/*
  Basis points, not percent: 10000 bps is the whole yield. The contract refuses anything above it.
  There is no default — how much of your members' yield you hand back is the whole proposition you
  are offering them, and nothing here is entitled to choose it for you.
*/
const rebateBps = Number(process.argv[3]);
if (!Number.isInteger(rebateBps) || rebateBps < 0 || rebateBps > 10000) {
  console.error('usage: node skills/members.mjs <validator address> <rebate bps>');
  console.error('the rebate is a whole number of basis points, 0 to 10000. 1500 is 15%.');
  process.exit(1);
}

const env = Object.fromEntries(
  readFileSync(`${LABS_OPT}/mcp.env`, 'utf8').split('\n').filter((l) => l.includes('=')).map((l) => {
    const i = l.indexOf('=');
    return [l.slice(0, i).trim(), l.slice(i + 1).trim().replace(/^"|"$/g, '')];
  }),
);
const keypair = Ed25519Keypair.fromSecretKey(env.WEIR_AGENT_KEY);
const address = keypair.getPublicKey().toSuiAddress();
const PKG = env.PROJECTX_SOCIAL_LATEST_PACKAGE_ID;
const PLATFORM = env.PROJECTX_SOCIAL_PLATFORM_ID;
const client = new SuiGrpcClient({ network: env.PROJECTX_SOCIAL_NETWORK ?? 'mainnet', baseUrl: env.PROJECTX_SOCIAL_GRPC_URL });

const profile = await fetch(`${BASE}/api/creator?owner=${address}`).then((r) => r.json());
if (!profile?.accountId) {
  console.log('no account yet — run vault.mjs first. Nothing was written.');
  process.exit(0);
}

/*
  One members vault, not one per run.

  `stake_vault::open` does not refuse a second vault — nothing in the contract stops an address
  owning two, and a second one would split the stake and leave the first stranded. Holding a
  StakeCap already is the proof there is one, so the open is skipped and only the rebate runs.
*/
const existing = await client.core.listOwnedObjects({ owner: address });
const existingCap = (existing?.objects ?? existing?.data ?? [])
  .filter((o) => String(o.type ?? o.objectType ?? '').includes('::stake_vault::StakeCap'))
  .map((o) => o.id ?? o.objectId)
  .find(Boolean);

if (existingCap) {
  console.log('members vault already open — skipping the open, setting the rebate only.');
}

if (!existingCap) {
const tx = new Transaction();
const cap = tx.moveCall({
  target: `${PKG}::stake_vault::open`,
  arguments: [tx.object(PLATFORM), tx.object(profile.accountId), tx.pure.address(validator)],
});
/* The cap is your authority over the vault. Unreturned, it is destroyed with the transaction. */
tx.transferObjects([cap], tx.pure.address(address));
tx.setSender(address);

const built = await tx.build({ client });
const sim = await client.core.simulateTransaction({ transaction: built, include: { effects: true } });
/*
  The node answers in an envelope: `Transaction` when it ran, `FailedTransaction` when it aborted.
  Success must be read positively. This transaction hands back a StakeCap and transfers it in the
  same call; signing one we did not understand is how a vault ends up beyond anyone's control.
*/
const envelope = sim?.Transaction ?? sim?.FailedTransaction ?? sim;
const status = envelope?.status ?? envelope?.effects?.status;
if (status?.success !== true) {
  console.log(`the chain refused to open the members vault: ${status?.error ?? 'the simulation returned no success'}`);
  console.log('nothing was signed and nothing was spent.');
  process.exit(0);
}

const { signature } = await keypair.signTransaction(built);
const res = await client.core.executeTransaction({ transaction: built, signatures: [signature] });
const digest = res?.transaction?.digest ?? res?.digest ?? null;
if (digest) await client.core.waitForTransaction({ digest });
console.log('members vault open. Your StakeCap is in your wallet — it is your authority over it.');
console.log(`validator ${validator}`);
console.log(`digest ${digest ?? '(submitted)'}`);
}

/*
  The rebate is a SECOND transaction and cannot be otherwise.

  `stake_vault::open` ends with `transfer::share_object(vault)`, and `set_rebate_bps` takes
  `&mut StakeVault`. A shared object created inside a transaction cannot be a mutable input to
  that same transaction — inputs are fixed when it is signed. So the vault must exist, and be
  shared, before its rebate can be set.

  The cap is the map to the vault, and effects are not: their shape differs by node version, and a
  miss there leaves the rebate silently at zero. `StakeCap` is `{ id: UID, vault: ID }` — two
  32-byte fields, in that order — so reading the cap this address owns gives the vault id with no
  parsing to get wrong, and gives it again on every later run.
*/
const owned = await client.core.listOwnedObjects({ owner: address });
const capId = (owned?.objects ?? owned?.data ?? [])
  .filter((o) => String(o.type ?? o.objectType ?? '').includes('::stake_vault::StakeCap'))
  .map((o) => o.id ?? o.objectId)
  .find(Boolean);

let vaultId;
if (capId) {
  const capObject = await client.core.getObject({ objectId: capId, include: { content: true } });
  const bytes = capObject?.object?.content;
  if (bytes && bytes.length >= 64) {
    vaultId = `0x${Buffer.from(bytes.slice(32, 64)).toString('hex')}`;
  }
}

if (!vaultId || !capId) {
  console.log('the vault is open, but this run could not find the StakeCap that points at it.');
  console.log('the rebate is still zero. Run this command again — the open step will be skipped.');
  process.exit(0);
}

const rebateTx = new Transaction();
rebateTx.moveCall({
  target: `${PKG}::stake_vault::set_rebate_bps`,
  arguments: [rebateTx.object(vaultId), rebateTx.object(capId), rebateTx.pure.u64(rebateBps)],
});
rebateTx.setSender(address);

const rebateBuilt = await rebateTx.build({ client });
const rebateSim = await client.core.simulateTransaction({ transaction: rebateBuilt, include: { effects: true } });
const rebateEnvelope = rebateSim?.Transaction ?? rebateSim?.FailedTransaction ?? rebateSim;
const rebateStatus = rebateEnvelope?.status ?? rebateEnvelope?.effects?.status;
if (rebateStatus?.success !== true) {
  console.log(`the vault is open, but the chain refused the rebate: ${rebateStatus?.error ?? 'the simulation returned no success'}`);
  console.log('the rebate is still zero. Nothing else was signed.');
  process.exit(0);
}

const { signature: rebateSignature } = await keypair.signTransaction(rebateBuilt);
const rebateRes = await client.core.executeTransaction({ transaction: rebateBuilt, signatures: [rebateSignature] });
const rebateDigest = rebateRes?.transaction?.digest ?? rebateRes?.digest ?? null;
if (rebateDigest) await client.core.waitForTransaction({ digest: rebateDigest });
console.log(`rebate set to ${rebateBps} bps — members keep ${(rebateBps / 100).toFixed(2)}% of the yield their principal earns.`);
console.log(`vault ${vaultId}`);
console.log(`digest ${rebateDigest ?? '(submitted)'}`);
